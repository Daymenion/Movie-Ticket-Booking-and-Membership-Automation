﻿namespace BookMyshow
{
    partial class signuppg
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(signuppg));
            this.loggrbx = new System.Windows.Forms.GroupBox();
            this.button1 = new System.Windows.Forms.Button();
            this.cpwdlbl = new System.Windows.Forms.Label();
            this.cpwdtxt = new System.Windows.Forms.TextBox();
            this.registerbtn = new System.Windows.Forms.Button();
            this.signuplbl = new System.Windows.Forms.Label();
            this.signinbtn = new System.Windows.Forms.Button();
            this.pwdtxt = new System.Windows.Forms.TextBox();
            this.usertxt = new System.Windows.Forms.TextBox();
            this.pwdbtn = new System.Windows.Forms.Label();
            this.userbtn = new System.Windows.Forms.Label();
            this.loggrbx.SuspendLayout();
            this.SuspendLayout();
            // 
            // loggrbx
            // 
            this.loggrbx.BackColor = System.Drawing.Color.Transparent;
            this.loggrbx.Controls.Add(this.button1);
            this.loggrbx.Controls.Add(this.cpwdlbl);
            this.loggrbx.Controls.Add(this.cpwdtxt);
            this.loggrbx.Controls.Add(this.registerbtn);
            this.loggrbx.Controls.Add(this.signuplbl);
            this.loggrbx.Controls.Add(this.signinbtn);
            this.loggrbx.Controls.Add(this.pwdtxt);
            this.loggrbx.Controls.Add(this.usertxt);
            this.loggrbx.Controls.Add(this.pwdbtn);
            this.loggrbx.Controls.Add(this.userbtn);
            this.loggrbx.Location = new System.Drawing.Point(3, 4);
            this.loggrbx.Margin = new System.Windows.Forms.Padding(2);
            this.loggrbx.Name = "loggrbx";
            this.loggrbx.Padding = new System.Windows.Forms.Padding(2);
            this.loggrbx.Size = new System.Drawing.Size(587, 356);
            this.loggrbx.TabIndex = 0;
            this.loggrbx.TabStop = false;
            this.loggrbx.Enter += new System.EventHandler(this.loggrbx_Enter);
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.button1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("button1.BackgroundImage")));
            this.button1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Location = new System.Drawing.Point(561, 7);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(25, 18);
            this.button1.TabIndex = 0;
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // cpwdlbl
            // 
            this.cpwdlbl.AutoSize = true;
            this.cpwdlbl.BackColor = System.Drawing.Color.Transparent;
            this.cpwdlbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cpwdlbl.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.cpwdlbl.Location = new System.Drawing.Point(41, 162);
            this.cpwdlbl.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.cpwdlbl.Name = "cpwdlbl";
            this.cpwdlbl.Size = new System.Drawing.Size(182, 25);
            this.cpwdlbl.TabIndex = 0;
            this.cpwdlbl.Text = "Confirm Password :";
            // 
            // cpwdtxt
            // 
            this.cpwdtxt.BackColor = System.Drawing.SystemColors.InactiveCaptionText;
            this.cpwdtxt.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cpwdtxt.ForeColor = System.Drawing.SystemColors.InactiveBorder;
            this.cpwdtxt.Location = new System.Drawing.Point(320, 159);
            this.cpwdtxt.Margin = new System.Windows.Forms.Padding(2);
            this.cpwdtxt.Name = "cpwdtxt";
            this.cpwdtxt.PasswordChar = '*';
            this.cpwdtxt.Size = new System.Drawing.Size(236, 30);
            this.cpwdtxt.TabIndex = 3;
            this.cpwdtxt.TextChanged += new System.EventHandler(this.cpwdtxt_TextChanged);
            // 
            // registerbtn
            // 
            this.registerbtn.BackColor = System.Drawing.Color.Black;
            this.registerbtn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.registerbtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.registerbtn.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.registerbtn.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.registerbtn.Location = new System.Drawing.Point(424, 209);
            this.registerbtn.Margin = new System.Windows.Forms.Padding(2);
            this.registerbtn.Name = "registerbtn";
            this.registerbtn.Size = new System.Drawing.Size(132, 33);
            this.registerbtn.TabIndex = 4;
            this.registerbtn.Text = "Register";
            this.registerbtn.UseVisualStyleBackColor = false;
            this.registerbtn.Click += new System.EventHandler(this.registerbtn_Click);
            // 
            // signuplbl
            // 
            this.signuplbl.AutoSize = true;
            this.signuplbl.BackColor = System.Drawing.Color.Transparent;
            this.signuplbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.signuplbl.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.signuplbl.Location = new System.Drawing.Point(41, 272);
            this.signuplbl.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.signuplbl.Name = "signuplbl";
            this.signuplbl.Size = new System.Drawing.Size(217, 25);
            this.signuplbl.TabIndex = 0;
            this.signuplbl.Text = "Already Have Account, ";
            // 
            // signinbtn
            // 
            this.signinbtn.BackColor = System.Drawing.Color.Black;
            this.signinbtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.signinbtn.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.signinbtn.Location = new System.Drawing.Point(440, 268);
            this.signinbtn.Margin = new System.Windows.Forms.Padding(2);
            this.signinbtn.Name = "signinbtn";
            this.signinbtn.Size = new System.Drawing.Size(116, 33);
            this.signinbtn.TabIndex = 5;
            this.signinbtn.Text = "Sign In Now";
            this.signinbtn.UseVisualStyleBackColor = false;
            this.signinbtn.Click += new System.EventHandler(this.signinbtn_Click);
            // 
            // pwdtxt
            // 
            this.pwdtxt.BackColor = System.Drawing.SystemColors.InactiveCaptionText;
            this.pwdtxt.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pwdtxt.ForeColor = System.Drawing.SystemColors.InactiveBorder;
            this.pwdtxt.Location = new System.Drawing.Point(320, 107);
            this.pwdtxt.Margin = new System.Windows.Forms.Padding(2);
            this.pwdtxt.Name = "pwdtxt";
            this.pwdtxt.PasswordChar = '*';
            this.pwdtxt.Size = new System.Drawing.Size(236, 30);
            this.pwdtxt.TabIndex = 2;
            // 
            // usertxt
            // 
            this.usertxt.BackColor = System.Drawing.SystemColors.InactiveCaptionText;
            this.usertxt.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.usertxt.ForeColor = System.Drawing.SystemColors.InactiveBorder;
            this.usertxt.Location = new System.Drawing.Point(320, 59);
            this.usertxt.Margin = new System.Windows.Forms.Padding(2);
            this.usertxt.Name = "usertxt";
            this.usertxt.Size = new System.Drawing.Size(236, 30);
            this.usertxt.TabIndex = 1;
            this.usertxt.Tag = "";
            // 
            // pwdbtn
            // 
            this.pwdbtn.AutoSize = true;
            this.pwdbtn.BackColor = System.Drawing.Color.Transparent;
            this.pwdbtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pwdbtn.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.pwdbtn.Location = new System.Drawing.Point(41, 110);
            this.pwdbtn.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.pwdbtn.Name = "pwdbtn";
            this.pwdbtn.Size = new System.Drawing.Size(109, 25);
            this.pwdbtn.TabIndex = 0;
            this.pwdbtn.Text = "Password :";
            // 
            // userbtn
            // 
            this.userbtn.AutoSize = true;
            this.userbtn.BackColor = System.Drawing.Color.Transparent;
            this.userbtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.userbtn.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.userbtn.Location = new System.Drawing.Point(41, 62);
            this.userbtn.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.userbtn.Name = "userbtn";
            this.userbtn.Size = new System.Drawing.Size(85, 25);
            this.userbtn.TabIndex = 0;
            this.userbtn.Text = "User Id :";
            // 
            // signuppg
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(593, 366);
            this.Controls.Add(this.loggrbx);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "signuppg";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "SignUp";
            this.Load += new System.EventHandler(this.signuppg_Load);
            this.loggrbx.ResumeLayout(false);
            this.loggrbx.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox loggrbx;
        private System.Windows.Forms.Button registerbtn;
        private System.Windows.Forms.Label signuplbl;
        private System.Windows.Forms.Button signinbtn;
        private System.Windows.Forms.TextBox pwdtxt;
        private System.Windows.Forms.TextBox usertxt;
        private System.Windows.Forms.Label pwdbtn;
        private System.Windows.Forms.Label userbtn;
        private System.Windows.Forms.Label cpwdlbl;
        private System.Windows.Forms.TextBox cpwdtxt;
        private System.Windows.Forms.Button button1;
    }
}

