﻿namespace BookMyshow
{
    partial class BookM
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(BookM));
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.comboBox4 = new System.Windows.Forms.ComboBox();
            this.comboBox3 = new System.Windows.Forms.ComboBox();
            this.label14 = new System.Windows.Forms.Label();
            this.comboBox2 = new System.Windows.Forms.ComboBox();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.datelbl = new System.Windows.Forms.Label();
            this.timelbl = new System.Windows.Forms.Label();
            this.theaterlbl = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.A6 = new System.Windows.Forms.Button();
            this.pecpricelbl = new System.Windows.Forms.Label();
            this.C3 = new System.Windows.Forms.Button();
            this.A5 = new System.Windows.Forms.Button();
            this.stpricelbl = new System.Windows.Forms.Label();
            this.C1 = new System.Windows.Forms.Button();
            this.A4 = new System.Windows.Forms.Button();
            this.C2 = new System.Windows.Forms.Button();
            this.A3 = new System.Windows.Forms.Button();
            this.prepriselbl = new System.Windows.Forms.Label();
            this.C4 = new System.Windows.Forms.Button();
            this.A2 = new System.Windows.Forms.Button();
            this.label12 = new System.Windows.Forms.Label();
            this.C5 = new System.Windows.Forms.Button();
            this.A1 = new System.Windows.Forms.Button();
            this.label10 = new System.Windows.Forms.Label();
            this.C6 = new System.Windows.Forms.Button();
            this.label8 = new System.Windows.Forms.Label();
            this.C7 = new System.Windows.Forms.Button();
            this.label7 = new System.Windows.Forms.Label();
            this.C8 = new System.Windows.Forms.Button();
            this.label6 = new System.Windows.Forms.Label();
            this.B8 = new System.Windows.Forms.Button();
            this.B7 = new System.Windows.Forms.Button();
            this.B6 = new System.Windows.Forms.Button();
            this.B5 = new System.Windows.Forms.Button();
            this.B4 = new System.Windows.Forms.Button();
            this.B3 = new System.Windows.Forms.Button();
            this.B2 = new System.Windows.Forms.Button();
            this.B1 = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.listBox1 = new System.Windows.Forms.ListBox();
            this.label13 = new System.Windows.Forms.Label();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.wallettxt = new System.Windows.Forms.TextBox();
            this.addwall = new System.Windows.Forms.Button();
            this.walletamt = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.label11 = new System.Windows.Forms.Label();
            this.time = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.groupBox1.Controls.Add(this.comboBox4);
            this.groupBox1.Controls.Add(this.comboBox3);
            this.groupBox1.Controls.Add(this.label14);
            this.groupBox1.Controls.Add(this.comboBox2);
            this.groupBox1.Controls.Add(this.comboBox1);
            this.groupBox1.Controls.Add(this.datelbl);
            this.groupBox1.Controls.Add(this.timelbl);
            this.groupBox1.Controls.Add(this.theaterlbl);
            this.groupBox1.Location = new System.Drawing.Point(16, 25);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(716, 171);
            this.groupBox1.TabIndex = 12;
            this.groupBox1.TabStop = false;
            this.groupBox1.Enter += new System.EventHandler(this.groupBox1_Enter);
            // 
            // comboBox4
            // 
            this.comboBox4.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.comboBox4.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.comboBox4.FormattingEnabled = true;
            this.comboBox4.Location = new System.Drawing.Point(151, 121);
            this.comboBox4.Name = "comboBox4";
            this.comboBox4.Size = new System.Drawing.Size(500, 21);
            this.comboBox4.TabIndex = 32;
            this.comboBox4.SelectedIndexChanged += new System.EventHandler(this.comboBox4_SelectedIndexChanged);
            // 
            // comboBox3
            // 
            this.comboBox3.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.comboBox3.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.comboBox3.FormattingEnabled = true;
            this.comboBox3.Location = new System.Drawing.Point(151, 26);
            this.comboBox3.Name = "comboBox3";
            this.comboBox3.Size = new System.Drawing.Size(500, 21);
            this.comboBox3.TabIndex = 31;
            this.comboBox3.SelectedIndexChanged += new System.EventHandler(this.comboBox3_SelectedIndexChanged);
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label14.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label14.Location = new System.Drawing.Point(50, 27);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(75, 13);
            this.label14.TabIndex = 30;
            this.label14.Text = "Select Movie :";
            // 
            // comboBox2
            // 
            this.comboBox2.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.comboBox2.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.comboBox2.FormattingEnabled = true;
            this.comboBox2.Location = new System.Drawing.Point(151, 59);
            this.comboBox2.Name = "comboBox2";
            this.comboBox2.Size = new System.Drawing.Size(500, 21);
            this.comboBox2.TabIndex = 29;
            this.comboBox2.SelectedIndexChanged += new System.EventHandler(this.comboBox2_SelectedIndexChanged);
            // 
            // comboBox1
            // 
            this.comboBox1.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.comboBox1.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Location = new System.Drawing.Point(151, 92);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(500, 21);
            this.comboBox1.TabIndex = 28;
            this.comboBox1.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            // 
            // datelbl
            // 
            this.datelbl.AutoSize = true;
            this.datelbl.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.datelbl.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.datelbl.Location = new System.Drawing.Point(50, 59);
            this.datelbl.Name = "datelbl";
            this.datelbl.Size = new System.Drawing.Size(69, 13);
            this.datelbl.TabIndex = 25;
            this.datelbl.Text = "Select Date :";
            // 
            // timelbl
            // 
            this.timelbl.AutoSize = true;
            this.timelbl.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.timelbl.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.timelbl.Location = new System.Drawing.Point(50, 124);
            this.timelbl.Name = "timelbl";
            this.timelbl.Size = new System.Drawing.Size(69, 13);
            this.timelbl.TabIndex = 23;
            this.timelbl.Text = "Select Time :";
            // 
            // theaterlbl
            // 
            this.theaterlbl.AutoSize = true;
            this.theaterlbl.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.theaterlbl.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.theaterlbl.Location = new System.Drawing.Point(50, 92);
            this.theaterlbl.Name = "theaterlbl";
            this.theaterlbl.Size = new System.Drawing.Size(83, 13);
            this.theaterlbl.TabIndex = 24;
            this.theaterlbl.Text = "Select Theater :";
            // 
            // groupBox2
            // 
            this.groupBox2.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.groupBox2.BackColor = System.Drawing.Color.Transparent;
            this.groupBox2.Controls.Add(this.A6);
            this.groupBox2.Controls.Add(this.pecpricelbl);
            this.groupBox2.Controls.Add(this.C3);
            this.groupBox2.Controls.Add(this.A5);
            this.groupBox2.Controls.Add(this.stpricelbl);
            this.groupBox2.Controls.Add(this.C1);
            this.groupBox2.Controls.Add(this.A4);
            this.groupBox2.Controls.Add(this.C2);
            this.groupBox2.Controls.Add(this.A3);
            this.groupBox2.Controls.Add(this.prepriselbl);
            this.groupBox2.Controls.Add(this.C4);
            this.groupBox2.Controls.Add(this.A2);
            this.groupBox2.Controls.Add(this.label12);
            this.groupBox2.Controls.Add(this.C5);
            this.groupBox2.Controls.Add(this.A1);
            this.groupBox2.Controls.Add(this.label10);
            this.groupBox2.Controls.Add(this.C6);
            this.groupBox2.Controls.Add(this.label8);
            this.groupBox2.Controls.Add(this.C7);
            this.groupBox2.Controls.Add(this.label7);
            this.groupBox2.Controls.Add(this.C8);
            this.groupBox2.Controls.Add(this.label6);
            this.groupBox2.Controls.Add(this.B8);
            this.groupBox2.Controls.Add(this.B7);
            this.groupBox2.Controls.Add(this.B6);
            this.groupBox2.Controls.Add(this.B5);
            this.groupBox2.Controls.Add(this.B4);
            this.groupBox2.Controls.Add(this.B3);
            this.groupBox2.Controls.Add(this.B2);
            this.groupBox2.Controls.Add(this.B1);
            this.groupBox2.Controls.Add(this.label5);
            this.groupBox2.Controls.Add(this.label4);
            this.groupBox2.Controls.Add(this.label3);
            this.groupBox2.Location = new System.Drawing.Point(16, 204);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(424, 318);
            this.groupBox2.TabIndex = 13;
            this.groupBox2.TabStop = false;
            this.groupBox2.Enter += new System.EventHandler(this.groupBox2_Enter);
            // 
            // A6
            // 
            this.A6.BackColor = System.Drawing.Color.White;
            this.A6.Font = new System.Drawing.Font("Microsoft Sans Serif", 5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.A6.Location = new System.Drawing.Point(261, 191);
            this.A6.Margin = new System.Windows.Forms.Padding(2);
            this.A6.Name = "A6";
            this.A6.Size = new System.Drawing.Size(20, 23);
            this.A6.TabIndex = 143;
            this.A6.Text = "A6";
            this.A6.UseVisualStyleBackColor = false;
            this.A6.Click += new System.EventHandler(this.A6_Click);
            // 
            // pecpricelbl
            // 
            this.pecpricelbl.AutoSize = true;
            this.pecpricelbl.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.pecpricelbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pecpricelbl.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.pecpricelbl.Location = new System.Drawing.Point(350, 72);
            this.pecpricelbl.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.pecpricelbl.Name = "pecpricelbl";
            this.pecpricelbl.Size = new System.Drawing.Size(0, 13);
            this.pecpricelbl.TabIndex = 137;
            // 
            // C3
            // 
            this.C3.BackColor = System.Drawing.Color.White;
            this.C3.Font = new System.Drawing.Font("Microsoft Sans Serif", 5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.C3.ForeColor = System.Drawing.SystemColors.ControlText;
            this.C3.Location = new System.Drawing.Point(164, 69);
            this.C3.Margin = new System.Windows.Forms.Padding(2);
            this.C3.Name = "C3";
            this.C3.Size = new System.Drawing.Size(20, 23);
            this.C3.TabIndex = 80;
            this.C3.Text = "C3";
            this.C3.UseVisualStyleBackColor = false;
            this.C3.Click += new System.EventHandler(this.C3_Click);
            // 
            // A5
            // 
            this.A5.BackColor = System.Drawing.Color.White;
            this.A5.Font = new System.Drawing.Font("Microsoft Sans Serif", 5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.A5.Location = new System.Drawing.Point(237, 191);
            this.A5.Margin = new System.Windows.Forms.Padding(2);
            this.A5.Name = "A5";
            this.A5.Size = new System.Drawing.Size(20, 23);
            this.A5.TabIndex = 142;
            this.A5.Text = "A5";
            this.A5.UseVisualStyleBackColor = false;
            this.A5.Click += new System.EventHandler(this.A5_Click);
            // 
            // stpricelbl
            // 
            this.stpricelbl.AutoSize = true;
            this.stpricelbl.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.stpricelbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.stpricelbl.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.stpricelbl.Location = new System.Drawing.Point(350, 194);
            this.stpricelbl.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.stpricelbl.Name = "stpricelbl";
            this.stpricelbl.Size = new System.Drawing.Size(0, 13);
            this.stpricelbl.TabIndex = 136;
            // 
            // C1
            // 
            this.C1.BackColor = System.Drawing.Color.White;
            this.C1.Font = new System.Drawing.Font("Microsoft Sans Serif", 5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.C1.ForeColor = System.Drawing.SystemColors.ControlText;
            this.C1.Location = new System.Drawing.Point(116, 69);
            this.C1.Margin = new System.Windows.Forms.Padding(2);
            this.C1.Name = "C1";
            this.C1.Size = new System.Drawing.Size(20, 23);
            this.C1.TabIndex = 78;
            this.C1.Text = "C1";
            this.C1.UseVisualStyleBackColor = false;
            this.C1.Click += new System.EventHandler(this.C1_Click);
            // 
            // A4
            // 
            this.A4.BackColor = System.Drawing.Color.White;
            this.A4.Font = new System.Drawing.Font("Microsoft Sans Serif", 5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.A4.Location = new System.Drawing.Point(213, 191);
            this.A4.Margin = new System.Windows.Forms.Padding(2);
            this.A4.Name = "A4";
            this.A4.Size = new System.Drawing.Size(20, 23);
            this.A4.TabIndex = 141;
            this.A4.Text = "A4";
            this.A4.UseVisualStyleBackColor = false;
            this.A4.Click += new System.EventHandler(this.A4_Click);
            // 
            // C2
            // 
            this.C2.BackColor = System.Drawing.Color.White;
            this.C2.Font = new System.Drawing.Font("Microsoft Sans Serif", 5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.C2.ForeColor = System.Drawing.SystemColors.ControlText;
            this.C2.Location = new System.Drawing.Point(140, 69);
            this.C2.Margin = new System.Windows.Forms.Padding(2);
            this.C2.Name = "C2";
            this.C2.Size = new System.Drawing.Size(20, 23);
            this.C2.TabIndex = 79;
            this.C2.Text = "C2";
            this.C2.UseVisualStyleBackColor = false;
            this.C2.Click += new System.EventHandler(this.C2_Click);
            // 
            // A3
            // 
            this.A3.BackColor = System.Drawing.Color.White;
            this.A3.Font = new System.Drawing.Font("Microsoft Sans Serif", 5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.A3.Location = new System.Drawing.Point(188, 191);
            this.A3.Margin = new System.Windows.Forms.Padding(2);
            this.A3.Name = "A3";
            this.A3.Size = new System.Drawing.Size(20, 23);
            this.A3.TabIndex = 140;
            this.A3.Text = "A3";
            this.A3.UseVisualStyleBackColor = false;
            this.A3.Click += new System.EventHandler(this.A3_Click);
            // 
            // prepriselbl
            // 
            this.prepriselbl.AutoSize = true;
            this.prepriselbl.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.prepriselbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.prepriselbl.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.prepriselbl.Location = new System.Drawing.Point(351, 133);
            this.prepriselbl.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.prepriselbl.Name = "prepriselbl";
            this.prepriselbl.Size = new System.Drawing.Size(0, 13);
            this.prepriselbl.TabIndex = 135;
            // 
            // C4
            // 
            this.C4.BackColor = System.Drawing.Color.White;
            this.C4.Font = new System.Drawing.Font("Microsoft Sans Serif", 5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.C4.ForeColor = System.Drawing.SystemColors.ControlText;
            this.C4.Location = new System.Drawing.Point(188, 69);
            this.C4.Margin = new System.Windows.Forms.Padding(2);
            this.C4.Name = "C4";
            this.C4.Size = new System.Drawing.Size(20, 23);
            this.C4.TabIndex = 81;
            this.C4.Text = "C4";
            this.C4.UseVisualStyleBackColor = false;
            this.C4.Click += new System.EventHandler(this.C4_Click);
            // 
            // A2
            // 
            this.A2.BackColor = System.Drawing.Color.White;
            this.A2.Font = new System.Drawing.Font("Microsoft Sans Serif", 5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.A2.Location = new System.Drawing.Point(164, 191);
            this.A2.Margin = new System.Windows.Forms.Padding(2);
            this.A2.Name = "A2";
            this.A2.Size = new System.Drawing.Size(20, 23);
            this.A2.TabIndex = 139;
            this.A2.Text = "A2";
            this.A2.UseVisualStyleBackColor = false;
            this.A2.Click += new System.EventHandler(this.A2_Click);
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label12.Location = new System.Drawing.Point(358, 39);
            this.label12.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(44, 13);
            this.label12.TabIndex = 133;
            this.label12.Text = "Price :";
            // 
            // C5
            // 
            this.C5.BackColor = System.Drawing.Color.White;
            this.C5.Font = new System.Drawing.Font("Microsoft Sans Serif", 5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.C5.ForeColor = System.Drawing.SystemColors.ControlText;
            this.C5.Location = new System.Drawing.Point(212, 69);
            this.C5.Margin = new System.Windows.Forms.Padding(2);
            this.C5.Name = "C5";
            this.C5.Size = new System.Drawing.Size(20, 23);
            this.C5.TabIndex = 82;
            this.C5.Text = "C5";
            this.C5.UseVisualStyleBackColor = false;
            this.C5.Click += new System.EventHandler(this.C5_Click);
            // 
            // A1
            // 
            this.A1.BackColor = System.Drawing.Color.White;
            this.A1.Font = new System.Drawing.Font("Microsoft Sans Serif", 5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.A1.Location = new System.Drawing.Point(140, 191);
            this.A1.Margin = new System.Windows.Forms.Padding(2);
            this.A1.Name = "A1";
            this.A1.Size = new System.Drawing.Size(20, 23);
            this.A1.TabIndex = 138;
            this.A1.Text = "A1";
            this.A1.UseVisualStyleBackColor = false;
            this.A1.Click += new System.EventHandler(this.A1_Click_1);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label10.Location = new System.Drawing.Point(27, 87);
            this.label10.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(14, 13);
            this.label10.TabIndex = 130;
            this.label10.Text = "C";
            // 
            // C6
            // 
            this.C6.BackColor = System.Drawing.Color.White;
            this.C6.Font = new System.Drawing.Font("Microsoft Sans Serif", 5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.C6.ForeColor = System.Drawing.SystemColors.ControlText;
            this.C6.Location = new System.Drawing.Point(237, 69);
            this.C6.Margin = new System.Windows.Forms.Padding(2);
            this.C6.Name = "C6";
            this.C6.Size = new System.Drawing.Size(20, 23);
            this.C6.TabIndex = 83;
            this.C6.Text = "C6";
            this.C6.UseVisualStyleBackColor = false;
            this.C6.Click += new System.EventHandler(this.C6_Click);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label8.Location = new System.Drawing.Point(27, 145);
            this.label8.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(14, 13);
            this.label8.TabIndex = 129;
            this.label8.Text = "B";
            // 
            // C7
            // 
            this.C7.BackColor = System.Drawing.Color.White;
            this.C7.Font = new System.Drawing.Font("Microsoft Sans Serif", 5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.C7.ForeColor = System.Drawing.SystemColors.ControlText;
            this.C7.Location = new System.Drawing.Point(261, 69);
            this.C7.Margin = new System.Windows.Forms.Padding(2);
            this.C7.Name = "C7";
            this.C7.Size = new System.Drawing.Size(20, 23);
            this.C7.TabIndex = 84;
            this.C7.Text = "C7";
            this.C7.UseVisualStyleBackColor = false;
            this.C7.Click += new System.EventHandler(this.C7_Click);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label7.Location = new System.Drawing.Point(27, 204);
            this.label7.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(14, 13);
            this.label7.TabIndex = 128;
            this.label7.Text = "A";
            // 
            // C8
            // 
            this.C8.BackColor = System.Drawing.Color.White;
            this.C8.Font = new System.Drawing.Font("Microsoft Sans Serif", 5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.C8.ForeColor = System.Drawing.SystemColors.ControlText;
            this.C8.Location = new System.Drawing.Point(285, 69);
            this.C8.Margin = new System.Windows.Forms.Padding(2);
            this.C8.Name = "C8";
            this.C8.Size = new System.Drawing.Size(20, 23);
            this.C8.TabIndex = 85;
            this.C8.Text = "C8";
            this.C8.UseVisualStyleBackColor = false;
            this.C8.Click += new System.EventHandler(this.C8_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label6.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label6.Location = new System.Drawing.Point(116, 46);
            this.label6.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(193, 15);
            this.label6.TabIndex = 127;
            this.label6.Text = "                    RECLINERS                     ";
            // 
            // B8
            // 
            this.B8.BackColor = System.Drawing.Color.White;
            this.B8.Font = new System.Drawing.Font("Microsoft Sans Serif", 5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.B8.Location = new System.Drawing.Point(285, 130);
            this.B8.Margin = new System.Windows.Forms.Padding(2);
            this.B8.Name = "B8";
            this.B8.Size = new System.Drawing.Size(20, 23);
            this.B8.TabIndex = 102;
            this.B8.Text = "B8";
            this.B8.UseVisualStyleBackColor = false;
            this.B8.Click += new System.EventHandler(this.B8_Click);
            // 
            // B7
            // 
            this.B7.BackColor = System.Drawing.Color.White;
            this.B7.Font = new System.Drawing.Font("Microsoft Sans Serif", 5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.B7.Location = new System.Drawing.Point(261, 130);
            this.B7.Margin = new System.Windows.Forms.Padding(2);
            this.B7.Name = "B7";
            this.B7.Size = new System.Drawing.Size(20, 23);
            this.B7.TabIndex = 101;
            this.B7.Text = "B7";
            this.B7.UseVisualStyleBackColor = false;
            this.B7.Click += new System.EventHandler(this.B7_Click);
            // 
            // B6
            // 
            this.B6.BackColor = System.Drawing.Color.White;
            this.B6.Font = new System.Drawing.Font("Microsoft Sans Serif", 5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.B6.Location = new System.Drawing.Point(237, 130);
            this.B6.Margin = new System.Windows.Forms.Padding(2);
            this.B6.Name = "B6";
            this.B6.Size = new System.Drawing.Size(20, 23);
            this.B6.TabIndex = 100;
            this.B6.Text = "B6";
            this.B6.UseVisualStyleBackColor = false;
            this.B6.Click += new System.EventHandler(this.B6_Click);
            // 
            // B5
            // 
            this.B5.BackColor = System.Drawing.Color.White;
            this.B5.Font = new System.Drawing.Font("Microsoft Sans Serif", 5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.B5.Location = new System.Drawing.Point(212, 130);
            this.B5.Margin = new System.Windows.Forms.Padding(2);
            this.B5.Name = "B5";
            this.B5.Size = new System.Drawing.Size(20, 23);
            this.B5.TabIndex = 99;
            this.B5.Text = "B5";
            this.B5.UseVisualStyleBackColor = false;
            this.B5.Click += new System.EventHandler(this.B5_Click);
            // 
            // B4
            // 
            this.B4.BackColor = System.Drawing.Color.White;
            this.B4.Font = new System.Drawing.Font("Microsoft Sans Serif", 5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.B4.Location = new System.Drawing.Point(188, 130);
            this.B4.Margin = new System.Windows.Forms.Padding(2);
            this.B4.Name = "B4";
            this.B4.Size = new System.Drawing.Size(20, 23);
            this.B4.TabIndex = 98;
            this.B4.Text = "B4";
            this.B4.UseVisualStyleBackColor = false;
            this.B4.Click += new System.EventHandler(this.B4_Click);
            // 
            // B3
            // 
            this.B3.BackColor = System.Drawing.Color.White;
            this.B3.Font = new System.Drawing.Font("Microsoft Sans Serif", 5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.B3.Location = new System.Drawing.Point(164, 130);
            this.B3.Margin = new System.Windows.Forms.Padding(2);
            this.B3.Name = "B3";
            this.B3.Size = new System.Drawing.Size(20, 23);
            this.B3.TabIndex = 97;
            this.B3.Text = "B3";
            this.B3.UseVisualStyleBackColor = false;
            this.B3.Click += new System.EventHandler(this.B3_Click);
            // 
            // B2
            // 
            this.B2.BackColor = System.Drawing.Color.White;
            this.B2.Font = new System.Drawing.Font("Microsoft Sans Serif", 5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.B2.Location = new System.Drawing.Point(140, 130);
            this.B2.Margin = new System.Windows.Forms.Padding(2);
            this.B2.Name = "B2";
            this.B2.Size = new System.Drawing.Size(20, 23);
            this.B2.TabIndex = 96;
            this.B2.Text = "B2";
            this.B2.UseVisualStyleBackColor = false;
            this.B2.Click += new System.EventHandler(this.B2_Click);
            // 
            // B1
            // 
            this.B1.BackColor = System.Drawing.Color.White;
            this.B1.Font = new System.Drawing.Font("Microsoft Sans Serif", 5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.B1.Location = new System.Drawing.Point(116, 130);
            this.B1.Margin = new System.Windows.Forms.Padding(2);
            this.B1.Name = "B1";
            this.B1.Size = new System.Drawing.Size(20, 23);
            this.B1.TabIndex = 95;
            this.B1.Text = "B1";
            this.B1.UseVisualStyleBackColor = false;
            this.B1.Click += new System.EventHandler(this.B1_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label5.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label5.Location = new System.Drawing.Point(117, 164);
            this.label5.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(188, 15);
            this.label5.TabIndex = 94;
            this.label5.Text = "                          STAR                        ";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label4.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label4.Location = new System.Drawing.Point(117, 104);
            this.label4.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(191, 15);
            this.label4.TabIndex = 61;
            this.label4.Text = "                      PREMIERE                    ";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label3.Location = new System.Drawing.Point(148, 295);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(129, 13);
            this.label3.TabIndex = 40;
            this.label3.Text = "All Eye\'s This Way Please";
            this.label3.Click += new System.EventHandler(this.label3_Click);
            // 
            // label1
            // 
            this.label1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label1.Location = new System.Drawing.Point(67, 191);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(48, 17);
            this.label1.TabIndex = 14;
            this.label1.Text = "Total :";
            // 
            // button1
            // 
            this.button1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.button1.Location = new System.Drawing.Point(179, 268);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 15;
            this.button1.Text = "Buy Now";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // label2
            // 
            this.label2.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(148, 192);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(16, 17);
            this.label2.TabIndex = 16;
            this.label2.Text = "0";
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // listBox1
            // 
            this.listBox1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.listBox1.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.listBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.listBox1.ForeColor = System.Drawing.SystemColors.InactiveBorder;
            this.listBox1.FormattingEnabled = true;
            this.listBox1.ItemHeight = 25;
            this.listBox1.Location = new System.Drawing.Point(469, 43);
            this.listBox1.Name = "listBox1";
            this.listBox1.Size = new System.Drawing.Size(251, 154);
            this.listBox1.TabIndex = 17;
            this.listBox1.Visible = false;
            this.listBox1.SelectedIndexChanged += new System.EventHandler(this.listBox1_SelectedIndexChanged);
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(0, 0);
            this.label13.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(41, 13);
            this.label13.TabIndex = 18;
            this.label13.Text = "label13";
            // 
            // groupBox3
            // 
            this.groupBox3.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.groupBox3.BackColor = System.Drawing.Color.Transparent;
            this.groupBox3.Controls.Add(this.wallettxt);
            this.groupBox3.Controls.Add(this.addwall);
            this.groupBox3.Controls.Add(this.walletamt);
            this.groupBox3.Controls.Add(this.label16);
            this.groupBox3.Controls.Add(this.label9);
            this.groupBox3.Controls.Add(this.button1);
            this.groupBox3.Controls.Add(this.label1);
            this.groupBox3.Controls.Add(this.label2);
            this.groupBox3.Location = new System.Drawing.Point(455, 204);
            this.groupBox3.Margin = new System.Windows.Forms.Padding(2);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Padding = new System.Windows.Forms.Padding(2);
            this.groupBox3.Size = new System.Drawing.Size(277, 318);
            this.groupBox3.TabIndex = 19;
            this.groupBox3.TabStop = false;
            // 
            // wallettxt
            // 
            this.wallettxt.Location = new System.Drawing.Point(49, 28);
            this.wallettxt.Name = "wallettxt";
            this.wallettxt.Size = new System.Drawing.Size(178, 20);
            this.wallettxt.TabIndex = 21;
            // 
            // addwall
            // 
            this.addwall.Location = new System.Drawing.Point(70, 68);
            this.addwall.Name = "addwall";
            this.addwall.Size = new System.Drawing.Size(127, 23);
            this.addwall.TabIndex = 20;
            this.addwall.Text = "Add/Update To Wallet";
            this.addwall.UseVisualStyleBackColor = true;
            this.addwall.Click += new System.EventHandler(this.addwall_Click);
            // 
            // walletamt
            // 
            this.walletamt.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.walletamt.AutoSize = true;
            this.walletamt.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.walletamt.ForeColor = System.Drawing.Color.White;
            this.walletamt.Location = new System.Drawing.Point(148, 136);
            this.walletamt.Name = "walletamt";
            this.walletamt.Size = new System.Drawing.Size(16, 17);
            this.walletamt.TabIndex = 19;
            this.walletamt.Text = "0";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(110, 51);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(41, 13);
            this.label16.TabIndex = 18;
            this.label16.Text = "label16";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.Color.White;
            this.label9.Location = new System.Drawing.Point(67, 135);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(55, 17);
            this.label9.TabIndex = 17;
            this.label9.Text = "Wallet :";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label15.Location = new System.Drawing.Point(13, 9);
            this.label15.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(28, 13);
            this.label15.TabIndex = 20;
            this.label15.Text = "date";
            // 
            // timer1
            // 
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.BackColor = System.Drawing.Color.White;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(12, 14);
            this.label11.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(0, 15);
            this.label11.TabIndex = 21;
            this.label11.Visible = false;
            // 
            // time
            // 
            this.time.AutoSize = true;
            this.time.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.time.Location = new System.Drawing.Point(79, 9);
            this.time.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.time.Name = "time";
            this.time.Size = new System.Drawing.Size(26, 13);
            this.time.TabIndex = 22;
            this.time.Text = "time";
            // 
            // BookM
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(754, 566);
            this.Controls.Add(this.time);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.listBox1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "BookM";
            this.Text = "BookM";
            this.Load += new System.EventHandler(this.BookM_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ListBox listBox1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label stpricelbl;
        private System.Windows.Forms.Label prepriselbl;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button B8;
        private System.Windows.Forms.Button B7;
        private System.Windows.Forms.Button B6;
        private System.Windows.Forms.Button B5;
        private System.Windows.Forms.Button B4;
        private System.Windows.Forms.Button B3;
        private System.Windows.Forms.Button B2;
        private System.Windows.Forms.Button B1;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button C8;
        private System.Windows.Forms.Button C7;
        private System.Windows.Forms.Button C6;
        private System.Windows.Forms.Button C5;
        private System.Windows.Forms.Button C4;
        private System.Windows.Forms.Button C3;
        private System.Windows.Forms.Button C2;
        private System.Windows.Forms.Button C1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.ComboBox comboBox2;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.Label datelbl;
        private System.Windows.Forms.Label timelbl;
        private System.Windows.Forms.Label theaterlbl;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.ComboBox comboBox3;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Label pecpricelbl;
        private System.Windows.Forms.ComboBox comboBox4;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Button A6;
        private System.Windows.Forms.Button A5;
        private System.Windows.Forms.Button A4;
        private System.Windows.Forms.Button A3;
        private System.Windows.Forms.Button A2;
        private System.Windows.Forms.Button A1;
        private System.Windows.Forms.Label time;
        private System.Windows.Forms.Label walletamt;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox wallettxt;
        private System.Windows.Forms.Button addwall;
    }
}