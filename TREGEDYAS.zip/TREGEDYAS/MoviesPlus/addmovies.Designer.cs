﻿namespace BookMyshow
{
    partial class addmovies
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(addmovies));
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.languagetxt = new System.Windows.Forms.ComboBox();
            this.datePicker = new System.Windows.Forms.DateTimePicker();
            this.TimePicker = new System.Windows.Forms.DateTimePicker();
            this.languagelbl = new System.Windows.Forms.Label();
            this.synopsislbl = new System.Windows.Forms.Label();
            this.posterurltxt = new System.Windows.Forms.TextBox();
            this.castlb = new System.Windows.Forms.Label();
            this.posterurl = new System.Windows.Forms.Label();
            this.durationlbl = new System.Windows.Forms.Label();
            this.youtubeurltxt = new System.Windows.Forms.TextBox();
            this.generlbl = new System.Windows.Forms.Label();
            this.youtubeurl = new System.Windows.Forms.Label();
            this.releaselbl = new System.Windows.Forms.Label();
            this.movienamelbl = new System.Windows.Forms.Label();
            this.synopisitxt = new System.Windows.Forms.TextBox();
            this.movieidlbl = new System.Windows.Forms.Label();
            this.ratingtxt = new System.Windows.Forms.TextBox();
            this.ratinglbl = new System.Windows.Forms.Label();
            this.addmoivebtn = new System.Windows.Forms.Button();
            this.movietxt = new System.Windows.Forms.TextBox();
            this.movienametxt = new System.Windows.Forms.TextBox();
            this.casttxt = new System.Windows.Forms.TextBox();
            this.moviegenertxt = new System.Windows.Forms.TextBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.mlistbx = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.picturebox = new System.Windows.Forms.GroupBox();
            this.button2 = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.videobox = new System.Windows.Forms.GroupBox();
            this.button3 = new System.Windows.Forms.Button();
            this.webBrowser = new System.Windows.Forms.WebBrowser();
            this.button4 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.picturebox.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.videobox.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.groupBox1.BackColor = System.Drawing.Color.Transparent;
            this.groupBox1.Controls.Add(this.groupBox3);
            this.groupBox1.Controls.Add(this.groupBox2);
            this.groupBox1.Location = new System.Drawing.Point(-1, -8);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(755, 578);
            this.groupBox1.TabIndex = 11;
            this.groupBox1.TabStop = false;
            this.groupBox1.Enter += new System.EventHandler(this.groupBox1_Enter);
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.picturebox);
            this.groupBox3.Controls.Add(this.button5);
            this.groupBox3.Controls.Add(this.videobox);
            this.groupBox3.Controls.Add(this.button4);
            this.groupBox3.Controls.Add(this.languagetxt);
            this.groupBox3.Controls.Add(this.datePicker);
            this.groupBox3.Controls.Add(this.TimePicker);
            this.groupBox3.Controls.Add(this.languagelbl);
            this.groupBox3.Controls.Add(this.synopsislbl);
            this.groupBox3.Controls.Add(this.posterurltxt);
            this.groupBox3.Controls.Add(this.castlb);
            this.groupBox3.Controls.Add(this.posterurl);
            this.groupBox3.Controls.Add(this.durationlbl);
            this.groupBox3.Controls.Add(this.youtubeurltxt);
            this.groupBox3.Controls.Add(this.generlbl);
            this.groupBox3.Controls.Add(this.youtubeurl);
            this.groupBox3.Controls.Add(this.releaselbl);
            this.groupBox3.Controls.Add(this.movienamelbl);
            this.groupBox3.Controls.Add(this.synopisitxt);
            this.groupBox3.Controls.Add(this.movieidlbl);
            this.groupBox3.Controls.Add(this.ratingtxt);
            this.groupBox3.Controls.Add(this.ratinglbl);
            this.groupBox3.Controls.Add(this.addmoivebtn);
            this.groupBox3.Controls.Add(this.movietxt);
            this.groupBox3.Controls.Add(this.movienametxt);
            this.groupBox3.Controls.Add(this.casttxt);
            this.groupBox3.Controls.Add(this.moviegenertxt);
            this.groupBox3.Location = new System.Drawing.Point(13, 143);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(730, 419);
            this.groupBox3.TabIndex = 27;
            this.groupBox3.TabStop = false;
            // 
            // languagetxt
            // 
            this.languagetxt.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.languagetxt.FormattingEnabled = true;
            this.languagetxt.Items.AddRange(new object[] {
            "English",
            "Hindi",
            "Marathi",
            "Telugu"});
            this.languagetxt.Location = new System.Drawing.Point(131, 232);
            this.languagetxt.Margin = new System.Windows.Forms.Padding(2);
            this.languagetxt.MaxDropDownItems = 30;
            this.languagetxt.Name = "languagetxt";
            this.languagetxt.Size = new System.Drawing.Size(225, 24);
            this.languagetxt.TabIndex = 7;
            // 
            // datePicker
            // 
            this.datePicker.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.datePicker.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.datePicker.Location = new System.Drawing.Point(471, 82);
            this.datePicker.Margin = new System.Windows.Forms.Padding(0);
            this.datePicker.Name = "datePicker";
            this.datePicker.Size = new System.Drawing.Size(220, 23);
            this.datePicker.TabIndex = 9;
            this.datePicker.ValueChanged += new System.EventHandler(this.datePicker_ValueChanged);
            // 
            // TimePicker
            // 
            this.TimePicker.CalendarForeColor = System.Drawing.Color.White;
            this.TimePicker.CustomFormat = "";
            this.TimePicker.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TimePicker.Format = System.Windows.Forms.DateTimePickerFormat.Time;
            this.TimePicker.Location = new System.Drawing.Point(131, 182);
            this.TimePicker.Name = "TimePicker";
            this.TimePicker.ShowUpDown = true;
            this.TimePicker.Size = new System.Drawing.Size(221, 23);
            this.TimePicker.TabIndex = 6;
            this.TimePicker.Value = new System.DateTime(2017, 6, 9, 21, 30, 0, 0);
            this.TimePicker.ValueChanged += new System.EventHandler(this.TimePicker_ValueChanged);
            // 
            // languagelbl
            // 
            this.languagelbl.AutoSize = true;
            this.languagelbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.languagelbl.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.languagelbl.Location = new System.Drawing.Point(32, 233);
            this.languagelbl.Name = "languagelbl";
            this.languagelbl.Size = new System.Drawing.Size(80, 17);
            this.languagelbl.TabIndex = 0;
            this.languagelbl.Text = "Language :";
            this.languagelbl.Click += new System.EventHandler(this.label3_Click);
            // 
            // synopsislbl
            // 
            this.synopsislbl.AutoSize = true;
            this.synopsislbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.synopsislbl.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.synopsislbl.Location = new System.Drawing.Point(32, 289);
            this.synopsislbl.Name = "synopsislbl";
            this.synopsislbl.Size = new System.Drawing.Size(73, 17);
            this.synopsislbl.TabIndex = 0;
            this.synopsislbl.Text = "Synopsis :";
            // 
            // posterurltxt
            // 
            this.posterurltxt.BackColor = System.Drawing.Color.White;
            this.posterurltxt.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.posterurltxt.ForeColor = System.Drawing.Color.Black;
            this.posterurltxt.Location = new System.Drawing.Point(470, 232);
            this.posterurltxt.Name = "posterurltxt";
            this.posterurltxt.Size = new System.Drawing.Size(198, 23);
            this.posterurltxt.TabIndex = 12;
            // 
            // castlb
            // 
            this.castlb.AutoSize = true;
            this.castlb.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.castlb.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.castlb.Location = new System.Drawing.Point(373, 33);
            this.castlb.Name = "castlb";
            this.castlb.Size = new System.Drawing.Size(44, 17);
            this.castlb.TabIndex = 0;
            this.castlb.Text = "Cast :";
            // 
            // posterurl
            // 
            this.posterurl.AutoSize = true;
            this.posterurl.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.posterurl.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.posterurl.Location = new System.Drawing.Point(373, 233);
            this.posterurl.Name = "posterurl";
            this.posterurl.Size = new System.Drawing.Size(79, 17);
            this.posterurl.TabIndex = 0;
            this.posterurl.Text = "Poster Url :";
            // 
            // durationlbl
            // 
            this.durationlbl.AutoSize = true;
            this.durationlbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.durationlbl.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.durationlbl.Location = new System.Drawing.Point(32, 183);
            this.durationlbl.Name = "durationlbl";
            this.durationlbl.Size = new System.Drawing.Size(70, 17);
            this.durationlbl.TabIndex = 0;
            this.durationlbl.Text = "Duration :";
            // 
            // youtubeurltxt
            // 
            this.youtubeurltxt.BackColor = System.Drawing.Color.White;
            this.youtubeurltxt.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.youtubeurltxt.ForeColor = System.Drawing.Color.Black;
            this.youtubeurltxt.Location = new System.Drawing.Point(470, 182);
            this.youtubeurltxt.Name = "youtubeurltxt";
            this.youtubeurltxt.Size = new System.Drawing.Size(198, 23);
            this.youtubeurltxt.TabIndex = 11;
            // 
            // generlbl
            // 
            this.generlbl.AutoSize = true;
            this.generlbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.generlbl.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.generlbl.Location = new System.Drawing.Point(32, 83);
            this.generlbl.Name = "generlbl";
            this.generlbl.Size = new System.Drawing.Size(97, 17);
            this.generlbl.TabIndex = 0;
            this.generlbl.Text = "Movie Gener :";
            this.generlbl.Click += new System.EventHandler(this.label1_Click);
            // 
            // youtubeurl
            // 
            this.youtubeurl.AutoSize = true;
            this.youtubeurl.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.youtubeurl.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.youtubeurl.Location = new System.Drawing.Point(373, 183);
            this.youtubeurl.Name = "youtubeurl";
            this.youtubeurl.Size = new System.Drawing.Size(91, 17);
            this.youtubeurl.TabIndex = 0;
            this.youtubeurl.Text = "Youtube Url :";
            // 
            // releaselbl
            // 
            this.releaselbl.AutoSize = true;
            this.releaselbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.releaselbl.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.releaselbl.Location = new System.Drawing.Point(373, 83);
            this.releaselbl.Name = "releaselbl";
            this.releaselbl.Size = new System.Drawing.Size(68, 17);
            this.releaselbl.TabIndex = 0;
            this.releaselbl.Text = "Release :";
            // 
            // movienamelbl
            // 
            this.movienamelbl.AutoSize = true;
            this.movienamelbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.movienamelbl.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.movienamelbl.Location = new System.Drawing.Point(32, 33);
            this.movienamelbl.Name = "movienamelbl";
            this.movienamelbl.Size = new System.Drawing.Size(94, 17);
            this.movienamelbl.TabIndex = 0;
            this.movienamelbl.Text = "Movie Name :";
            // 
            // synopisitxt
            // 
            this.synopisitxt.BackColor = System.Drawing.Color.White;
            this.synopisitxt.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.synopisitxt.ForeColor = System.Drawing.Color.Black;
            this.synopisitxt.Location = new System.Drawing.Point(131, 286);
            this.synopisitxt.Multiline = true;
            this.synopisitxt.Name = "synopisitxt";
            this.synopisitxt.Size = new System.Drawing.Size(560, 69);
            this.synopisitxt.TabIndex = 13;
            this.synopisitxt.TextChanged += new System.EventHandler(this.textBox9_TextChanged);
            // 
            // movieidlbl
            // 
            this.movieidlbl.AutoSize = true;
            this.movieidlbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.movieidlbl.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.movieidlbl.Location = new System.Drawing.Point(34, 133);
            this.movieidlbl.Name = "movieidlbl";
            this.movieidlbl.Size = new System.Drawing.Size(68, 17);
            this.movieidlbl.TabIndex = 0;
            this.movieidlbl.Text = "Movie Id :";
            this.movieidlbl.Click += new System.EventHandler(this.movieidlbl_Click);
            // 
            // ratingtxt
            // 
            this.ratingtxt.BackColor = System.Drawing.Color.White;
            this.ratingtxt.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ratingtxt.ForeColor = System.Drawing.Color.Black;
            this.ratingtxt.Location = new System.Drawing.Point(470, 132);
            this.ratingtxt.Name = "ratingtxt";
            this.ratingtxt.Size = new System.Drawing.Size(221, 23);
            this.ratingtxt.TabIndex = 10;
            // 
            // ratinglbl
            // 
            this.ratinglbl.AutoSize = true;
            this.ratinglbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ratinglbl.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.ratinglbl.Location = new System.Drawing.Point(373, 133);
            this.ratinglbl.Name = "ratinglbl";
            this.ratinglbl.Size = new System.Drawing.Size(57, 17);
            this.ratinglbl.TabIndex = 0;
            this.ratinglbl.Text = "Rating :";
            // 
            // addmoivebtn
            // 
            this.addmoivebtn.BackColor = System.Drawing.Color.Black;
            this.addmoivebtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.addmoivebtn.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.addmoivebtn.Location = new System.Drawing.Point(557, 371);
            this.addmoivebtn.Name = "addmoivebtn";
            this.addmoivebtn.Size = new System.Drawing.Size(134, 27);
            this.addmoivebtn.TabIndex = 14;
            this.addmoivebtn.Text = "Add Movie";
            this.addmoivebtn.UseVisualStyleBackColor = false;
            this.addmoivebtn.Click += new System.EventHandler(this.addmoivebtn_Click);
            // 
            // movietxt
            // 
            this.movietxt.BackColor = System.Drawing.Color.White;
            this.movietxt.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.movietxt.ForeColor = System.Drawing.Color.Black;
            this.movietxt.Location = new System.Drawing.Point(131, 132);
            this.movietxt.Name = "movietxt";
            this.movietxt.Size = new System.Drawing.Size(221, 23);
            this.movietxt.TabIndex = 5;
            // 
            // movienametxt
            // 
            this.movienametxt.BackColor = System.Drawing.Color.White;
            this.movienametxt.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.movienametxt.ForeColor = System.Drawing.Color.Black;
            this.movienametxt.Location = new System.Drawing.Point(131, 32);
            this.movienametxt.Name = "movienametxt";
            this.movienametxt.Size = new System.Drawing.Size(221, 23);
            this.movienametxt.TabIndex = 3;
            // 
            // casttxt
            // 
            this.casttxt.BackColor = System.Drawing.Color.White;
            this.casttxt.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.casttxt.ForeColor = System.Drawing.Color.Black;
            this.casttxt.Location = new System.Drawing.Point(470, 32);
            this.casttxt.Name = "casttxt";
            this.casttxt.Size = new System.Drawing.Size(221, 23);
            this.casttxt.TabIndex = 8;
            // 
            // moviegenertxt
            // 
            this.moviegenertxt.BackColor = System.Drawing.Color.White;
            this.moviegenertxt.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.moviegenertxt.ForeColor = System.Drawing.Color.Black;
            this.moviegenertxt.Location = new System.Drawing.Point(131, 82);
            this.moviegenertxt.Name = "moviegenertxt";
            this.moviegenertxt.Size = new System.Drawing.Size(221, 23);
            this.moviegenertxt.TabIndex = 4;
            this.moviegenertxt.TextChanged += new System.EventHandler(this.textBox4_TextChanged);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.mlistbx);
            this.groupBox2.Controls.Add(this.label1);
            this.groupBox2.Controls.Add(this.button1);
            this.groupBox2.Location = new System.Drawing.Point(13, 19);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(730, 118);
            this.groupBox2.TabIndex = 12;
            this.groupBox2.TabStop = false;
            // 
            // mlistbx
            // 
            this.mlistbx.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.mlistbx.FormattingEnabled = true;
            this.mlistbx.Location = new System.Drawing.Point(131, 29);
            this.mlistbx.Margin = new System.Windows.Forms.Padding(2);
            this.mlistbx.MaxDropDownItems = 30;
            this.mlistbx.Name = "mlistbx";
            this.mlistbx.Size = new System.Drawing.Size(560, 24);
            this.mlistbx.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label1.Location = new System.Drawing.Point(34, 32);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(84, 17);
            this.label1.TabIndex = 0;
            this.label1.Text = "Movie Title :";
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.Black;
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button1.Location = new System.Drawing.Point(572, 70);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(119, 29);
            this.button1.TabIndex = 2;
            this.button1.Text = "Delete Movie";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click_1);
            // 
            // picturebox
            // 
            this.picturebox.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
            | System.Windows.Forms.AnchorStyles.Left)
            | System.Windows.Forms.AnchorStyles.Right)));
            this.picturebox.Controls.Add(this.button2);
            this.picturebox.Controls.Add(this.pictureBox1);
            this.picturebox.Enabled = false;
            this.picturebox.Location = new System.Drawing.Point(273, 26);
            this.picturebox.Name = "picturebox";
            this.picturebox.Size = new System.Drawing.Size(234, 318);
            this.picturebox.TabIndex = 15;
            this.picturebox.TabStop = false;
            this.picturebox.Visible = false;
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.button2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("button2.BackgroundImage")));
            this.button2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button2.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.button2.Location = new System.Drawing.Point(207, 9);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(25, 18);
            this.button2.TabIndex = 8;
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.InitialImage = global::MoviesPlus.Properties.Resources.KAIST_loading;
            this.pictureBox1.Location = new System.Drawing.Point(19, 31);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(193, 263);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 9;
            this.pictureBox1.TabStop = false;
            // 
            // videobox
            // 
            this.videobox.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
            | System.Windows.Forms.AnchorStyles.Left)
            | System.Windows.Forms.AnchorStyles.Right)));
            this.videobox.Controls.Add(this.button3);
            this.videobox.Controls.Add(this.webBrowser);
            this.videobox.Enabled = false;
            this.videobox.Location = new System.Drawing.Point(150, 27);
            this.videobox.Name = "videobox";
            this.videobox.Size = new System.Drawing.Size(464, 352);
            this.videobox.TabIndex = 16;
            this.videobox.TabStop = false;
            this.videobox.Visible = false;
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.button3.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("button3.BackgroundImage")));
            this.button3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button3.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.button3.Location = new System.Drawing.Point(438, 9);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(25, 18);
            this.button3.TabIndex = 8;
            this.button3.UseVisualStyleBackColor = false;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // webBrowser
            // 
            this.webBrowser.Location = new System.Drawing.Point(20, 33);
            this.webBrowser.Margin = new System.Windows.Forms.Padding(2);
            this.webBrowser.Name = "webBrowser";
            this.webBrowser.Size = new System.Drawing.Size(400, 240);
            this.webBrowser.TabIndex = 32;
            // 
            // button4
            // 
            this.button4.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("button4.BackgroundImage")));
            this.button4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button4.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button4.Location = new System.Drawing.Point(665, 182);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(26, 23);
            this.button4.TabIndex = 15;
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // button5
            // 
            this.button5.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("button5.BackgroundImage")));
            this.button5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button5.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button5.Location = new System.Drawing.Point(665, 232);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(26, 23);
            this.button5.TabIndex = 16;
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // addmovies
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(754, 566);
            this.Controls.Add(this.groupBox1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "addmovies";
            this.Text = "manage";
            this.Load += new System.EventHandler(this.manage_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.picturebox.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.videobox.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox posterurltxt;
        private System.Windows.Forms.Label posterurl;
        private System.Windows.Forms.TextBox youtubeurltxt;
        private System.Windows.Forms.Label youtubeurl;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox synopisitxt;
        private System.Windows.Forms.TextBox ratingtxt;
        private System.Windows.Forms.TextBox movietxt;
        private System.Windows.Forms.TextBox moviegenertxt;
        private System.Windows.Forms.TextBox casttxt;
        private System.Windows.Forms.TextBox movienametxt;
        private System.Windows.Forms.Button addmoivebtn;
        private System.Windows.Forms.Label ratinglbl;
        private System.Windows.Forms.Label movieidlbl;
        private System.Windows.Forms.Label movienamelbl;
        private System.Windows.Forms.Label releaselbl;
        private System.Windows.Forms.Label generlbl;
        private System.Windows.Forms.Label durationlbl;
        private System.Windows.Forms.Label castlb;
        private System.Windows.Forms.Label synopsislbl;
        private System.Windows.Forms.Label languagelbl;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.ComboBox mlistbx;
        private System.Windows.Forms.DateTimePicker TimePicker;
        private System.Windows.Forms.DateTimePicker datePicker;
        private System.Windows.Forms.ComboBox languagetxt;
        private System.Windows.Forms.GroupBox picturebox;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.GroupBox videobox;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.WebBrowser webBrowser;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button button4;
    }
}