﻿namespace BookMyshow
{
    partial class Movied
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Movied));
            this.webBrowser = new System.Windows.Forms.WebBrowser();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.casttxt = new System.Windows.Forms.Label();
            this.synopsistxt = new System.Windows.Forms.Label();
            this.releasetxt = new System.Windows.Forms.Label();
            this.languagetxt = new System.Windows.Forms.Label();
            this.durationtxt = new System.Windows.Forms.Label();
            this.Midtxt = new System.Windows.Forms.Label();
            this.mgenertxt = new System.Windows.Forms.Label();
            this.mnametxt = new System.Windows.Forms.Label();
            this.movieidlbl = new System.Windows.Forms.Label();
            this.movienamelbl = new System.Windows.Forms.Label();
            this.releaselbl = new System.Windows.Forms.Label();
            this.generlbl = new System.Windows.Forms.Label();
            this.durationlbl = new System.Windows.Forms.Label();
            this.castlb = new System.Windows.Forms.Label();
            this.languagelbl = new System.Windows.Forms.Label();
            this.ratingtxt = new System.Windows.Forms.Label();
            this.bookbtn = new System.Windows.Forms.Button();
            this.ratinglbl = new System.Windows.Forms.Label();
            this.synopsislbl = new System.Windows.Forms.Label();
            this.mlistbx = new System.Windows.Forms.ComboBox();
            this.showdetail = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // webBrowser
            // 
            this.webBrowser.Location = new System.Drawing.Point(15, 223);
            this.webBrowser.Margin = new System.Windows.Forms.Padding(2);
            this.webBrowser.Name = "webBrowser";
            this.webBrowser.ScrollBarsEnabled = false;
            this.webBrowser.Size = new System.Drawing.Size(400, 240);
            this.webBrowser.TabIndex = 31;
            // 
            // groupBox1
            // 
            this.groupBox1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.groupBox1.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.groupBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.groupBox1.Controls.Add(this.casttxt);
            this.groupBox1.Controls.Add(this.synopsistxt);
            this.groupBox1.Controls.Add(this.releasetxt);
            this.groupBox1.Controls.Add(this.languagetxt);
            this.groupBox1.Controls.Add(this.durationtxt);
            this.groupBox1.Controls.Add(this.Midtxt);
            this.groupBox1.Controls.Add(this.mgenertxt);
            this.groupBox1.Controls.Add(this.mnametxt);
            this.groupBox1.Controls.Add(this.movieidlbl);
            this.groupBox1.Controls.Add(this.movienamelbl);
            this.groupBox1.Controls.Add(this.releaselbl);
            this.groupBox1.Controls.Add(this.generlbl);
            this.groupBox1.Controls.Add(this.durationlbl);
            this.groupBox1.Controls.Add(this.castlb);
            this.groupBox1.Controls.Add(this.languagelbl);
            this.groupBox1.Controls.Add(this.ratingtxt);
            this.groupBox1.Controls.Add(this.bookbtn);
            this.groupBox1.Controls.Add(this.ratinglbl);
            this.groupBox1.Controls.Add(this.synopsislbl);
            this.groupBox1.Controls.Add(this.webBrowser);
            this.groupBox1.ForeColor = System.Drawing.Color.Transparent;
            this.groupBox1.Location = new System.Drawing.Point(12, 59);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(730, 492);
            this.groupBox1.TabIndex = 13;
            this.groupBox1.TabStop = false;
            this.groupBox1.Visible = false;
            this.groupBox1.Enter += new System.EventHandler(this.groupBox1_Enter);
            // 
            // casttxt
            // 
            this.casttxt.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.casttxt.Location = new System.Drawing.Point(524, 291);
            this.casttxt.Name = "casttxt";
            this.casttxt.Size = new System.Drawing.Size(200, 128);
            this.casttxt.TabIndex = 34;
            // 
            // synopsistxt
            // 
            this.synopsistxt.Font = new System.Drawing.Font("Microsoft Sans Serif", 7F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.synopsistxt.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.synopsistxt.Location = new System.Drawing.Point(421, 27);
            this.synopsistxt.Name = "synopsistxt";
            this.synopsistxt.Size = new System.Drawing.Size(296, 183);
            this.synopsistxt.TabIndex = 33;
            this.synopsistxt.Text = "  ";
            // 
            // releasetxt
            // 
            this.releasetxt.AutoSize = true;
            this.releasetxt.BackColor = System.Drawing.Color.Transparent;
            this.releasetxt.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.releasetxt.Location = new System.Drawing.Point(104, 184);
            this.releasetxt.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.releasetxt.Name = "releasetxt";
            this.releasetxt.Size = new System.Drawing.Size(19, 13);
            this.releasetxt.TabIndex = 27;
            this.releasetxt.Text = "    ";
            this.releasetxt.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // languagetxt
            // 
            this.languagetxt.AutoSize = true;
            this.languagetxt.BackColor = System.Drawing.Color.Transparent;
            this.languagetxt.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.languagetxt.Location = new System.Drawing.Point(104, 150);
            this.languagetxt.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.languagetxt.Name = "languagetxt";
            this.languagetxt.Size = new System.Drawing.Size(19, 13);
            this.languagetxt.TabIndex = 25;
            this.languagetxt.Text = "    ";
            this.languagetxt.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.languagetxt.Click += new System.EventHandler(this.Language_Click);
            // 
            // durationtxt
            // 
            this.durationtxt.AutoSize = true;
            this.durationtxt.BackColor = System.Drawing.Color.Transparent;
            this.durationtxt.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.durationtxt.Location = new System.Drawing.Point(104, 118);
            this.durationtxt.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.durationtxt.Name = "durationtxt";
            this.durationtxt.Size = new System.Drawing.Size(19, 13);
            this.durationtxt.TabIndex = 24;
            this.durationtxt.Text = "    ";
            this.durationtxt.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.durationtxt.Click += new System.EventHandler(this.duration_Click);
            // 
            // Midtxt
            // 
            this.Midtxt.AutoSize = true;
            this.Midtxt.BackColor = System.Drawing.Color.Transparent;
            this.Midtxt.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.Midtxt.Location = new System.Drawing.Point(104, 88);
            this.Midtxt.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.Midtxt.Name = "Midtxt";
            this.Midtxt.Size = new System.Drawing.Size(19, 13);
            this.Midtxt.TabIndex = 23;
            this.Midtxt.Text = "    ";
            this.Midtxt.Click += new System.EventHandler(this.Mdi_Click);
            // 
            // mgenertxt
            // 
            this.mgenertxt.AutoSize = true;
            this.mgenertxt.BackColor = System.Drawing.Color.Transparent;
            this.mgenertxt.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.mgenertxt.Location = new System.Drawing.Point(104, 59);
            this.mgenertxt.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.mgenertxt.Name = "mgenertxt";
            this.mgenertxt.Size = new System.Drawing.Size(19, 13);
            this.mgenertxt.TabIndex = 22;
            this.mgenertxt.Text = "    ";
            this.mgenertxt.Click += new System.EventHandler(this.mgener_Click);
            // 
            // mnametxt
            // 
            this.mnametxt.AutoSize = true;
            this.mnametxt.BackColor = System.Drawing.Color.Transparent;
            this.mnametxt.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.mnametxt.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.mnametxt.Location = new System.Drawing.Point(104, 29);
            this.mnametxt.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.mnametxt.Name = "mnametxt";
            this.mnametxt.Size = new System.Drawing.Size(23, 15);
            this.mnametxt.TabIndex = 21;
            this.mnametxt.Text = "    ";
            this.mnametxt.Click += new System.EventHandler(this.mname_Click);
            // 
            // movieidlbl
            // 
            this.movieidlbl.AutoSize = true;
            this.movieidlbl.BackColor = System.Drawing.Color.Transparent;
            this.movieidlbl.Font = new System.Drawing.Font("Microsoft PhagsPa", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.movieidlbl.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.movieidlbl.Location = new System.Drawing.Point(12, 87);
            this.movieidlbl.Name = "movieidlbl";
            this.movieidlbl.Size = new System.Drawing.Size(56, 14);
            this.movieidlbl.TabIndex = 10;
            this.movieidlbl.Text = "Movie ID :";
            // 
            // movienamelbl
            // 
            this.movienamelbl.AutoSize = true;
            this.movienamelbl.BackColor = System.Drawing.Color.Transparent;
            this.movienamelbl.Font = new System.Drawing.Font("Microsoft PhagsPa", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.movienamelbl.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.movienamelbl.Location = new System.Drawing.Point(12, 27);
            this.movienamelbl.Name = "movienamelbl";
            this.movienamelbl.Size = new System.Drawing.Size(74, 14);
            this.movienamelbl.TabIndex = 0;
            this.movienamelbl.Text = "Movie Name :";
            // 
            // releaselbl
            // 
            this.releaselbl.AutoSize = true;
            this.releaselbl.BackColor = System.Drawing.Color.Transparent;
            this.releaselbl.Font = new System.Drawing.Font("Microsoft PhagsPa", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.releaselbl.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.releaselbl.Location = new System.Drawing.Point(13, 179);
            this.releaselbl.Name = "releaselbl";
            this.releaselbl.Size = new System.Drawing.Size(51, 14);
            this.releaselbl.TabIndex = 9;
            this.releaselbl.Text = "Release :";
            // 
            // generlbl
            // 
            this.generlbl.AutoSize = true;
            this.generlbl.BackColor = System.Drawing.Color.Transparent;
            this.generlbl.Font = new System.Drawing.Font("Microsoft PhagsPa", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.generlbl.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.generlbl.Location = new System.Drawing.Point(12, 57);
            this.generlbl.Name = "generlbl";
            this.generlbl.Size = new System.Drawing.Size(75, 14);
            this.generlbl.TabIndex = 3;
            this.generlbl.Text = "Movie Gener :";
            // 
            // durationlbl
            // 
            this.durationlbl.AutoSize = true;
            this.durationlbl.BackColor = System.Drawing.Color.Transparent;
            this.durationlbl.Font = new System.Drawing.Font("Microsoft PhagsPa", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.durationlbl.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.durationlbl.Location = new System.Drawing.Point(12, 117);
            this.durationlbl.Name = "durationlbl";
            this.durationlbl.Size = new System.Drawing.Size(55, 14);
            this.durationlbl.TabIndex = 8;
            this.durationlbl.Text = "Duration :";
            // 
            // castlb
            // 
            this.castlb.AutoSize = true;
            this.castlb.BackColor = System.Drawing.Color.Transparent;
            this.castlb.Font = new System.Drawing.Font("Microsoft PhagsPa", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.castlb.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.castlb.Location = new System.Drawing.Point(484, 291);
            this.castlb.Name = "castlb";
            this.castlb.Size = new System.Drawing.Size(34, 14);
            this.castlb.TabIndex = 4;
            this.castlb.Text = "Cast :";
            // 
            // languagelbl
            // 
            this.languagelbl.AutoSize = true;
            this.languagelbl.BackColor = System.Drawing.Color.Transparent;
            this.languagelbl.Font = new System.Drawing.Font("Microsoft PhagsPa", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.languagelbl.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.languagelbl.Location = new System.Drawing.Point(12, 149);
            this.languagelbl.Name = "languagelbl";
            this.languagelbl.Size = new System.Drawing.Size(59, 14);
            this.languagelbl.TabIndex = 6;
            this.languagelbl.Text = "Language :";
            // 
            // ratingtxt
            // 
            this.ratingtxt.AutoSize = true;
            this.ratingtxt.BackColor = System.Drawing.Color.Transparent;
            this.ratingtxt.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.ratingtxt.Location = new System.Drawing.Point(533, 255);
            this.ratingtxt.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.ratingtxt.Name = "ratingtxt";
            this.ratingtxt.Size = new System.Drawing.Size(13, 13);
            this.ratingtxt.TabIndex = 28;
            this.ratingtxt.Text = "  ";
            this.ratingtxt.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // bookbtn
            // 
            this.bookbtn.BackColor = System.Drawing.Color.Black;
            this.bookbtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bookbtn.ForeColor = System.Drawing.Color.White;
            this.bookbtn.Location = new System.Drawing.Point(598, 441);
            this.bookbtn.Name = "bookbtn";
            this.bookbtn.Size = new System.Drawing.Size(119, 29);
            this.bookbtn.TabIndex = 11;
            this.bookbtn.Text = "Book Now";
            this.bookbtn.UseVisualStyleBackColor = false;
            this.bookbtn.Click += new System.EventHandler(this.addmoivebtn_Click);
            // 
            // ratinglbl
            // 
            this.ratinglbl.AutoSize = true;
            this.ratinglbl.BackColor = System.Drawing.Color.Transparent;
            this.ratinglbl.Font = new System.Drawing.Font("Microsoft PhagsPa", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ratinglbl.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.ratinglbl.Location = new System.Drawing.Point(484, 255);
            this.ratinglbl.Name = "ratinglbl";
            this.ratinglbl.Size = new System.Drawing.Size(44, 14);
            this.ratinglbl.TabIndex = 7;
            this.ratinglbl.Text = "Rating :";
            // 
            // synopsislbl
            // 
            this.synopsislbl.AutoSize = true;
            this.synopsislbl.BackColor = System.Drawing.Color.Transparent;
            this.synopsislbl.Font = new System.Drawing.Font("Microsoft PhagsPa", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.synopsislbl.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.synopsislbl.Location = new System.Drawing.Point(361, 27);
            this.synopsislbl.Name = "synopsislbl";
            this.synopsislbl.Size = new System.Drawing.Size(54, 14);
            this.synopsislbl.TabIndex = 5;
            this.synopsislbl.Text = "Synopsis :";
            // 
            // mlistbx
            // 
            this.mlistbx.FormattingEnabled = true;
            this.mlistbx.Location = new System.Drawing.Point(12, 26);
            this.mlistbx.Margin = new System.Windows.Forms.Padding(2);
            this.mlistbx.Name = "mlistbx";
            this.mlistbx.Size = new System.Drawing.Size(610, 21);
            this.mlistbx.TabIndex = 14;
            this.mlistbx.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            // 
            // showdetail
            // 
            this.showdetail.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.showdetail.BackColor = System.Drawing.Color.Black;
            this.showdetail.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.showdetail.ForeColor = System.Drawing.Color.White;
            this.showdetail.Location = new System.Drawing.Point(647, 30);
            this.showdetail.Margin = new System.Windows.Forms.Padding(2);
            this.showdetail.Name = "showdetail";
            this.showdetail.Size = new System.Drawing.Size(95, 24);
            this.showdetail.TabIndex = 15;
            this.showdetail.Text = "Show Detail";
            this.showdetail.UseVisualStyleBackColor = false;
            this.showdetail.Click += new System.EventHandler(this.showdetail_Click);
            // 
            // Movied
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(754, 566);
            this.Controls.Add(this.showdetail);
            this.Controls.Add(this.mlistbx);
            this.Controls.Add(this.groupBox1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Movied";
            this.Text = "Movied";
            this.Load += new System.EventHandler(this.Movied_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.WebBrowser webBrowser;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label casttxt;
        private System.Windows.Forms.Label synopsistxt;
        private System.Windows.Forms.Label releasetxt;
        private System.Windows.Forms.Label languagetxt;
        private System.Windows.Forms.Label durationtxt;
        private System.Windows.Forms.Label Midtxt;
        private System.Windows.Forms.Label mgenertxt;
        private System.Windows.Forms.Label mnametxt;
        private System.Windows.Forms.Label movieidlbl;
        private System.Windows.Forms.Label movienamelbl;
        private System.Windows.Forms.Label releaselbl;
        private System.Windows.Forms.Label generlbl;
        private System.Windows.Forms.Label durationlbl;
        private System.Windows.Forms.Label castlb;
        private System.Windows.Forms.Label languagelbl;
        private System.Windows.Forms.Label ratingtxt;
        private System.Windows.Forms.Button bookbtn;
        private System.Windows.Forms.Label ratinglbl;
        private System.Windows.Forms.Label synopsislbl;
        private System.Windows.Forms.ComboBox mlistbx;
        private System.Windows.Forms.Button showdetail;
    }
}