﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BookMyshow
{
    public class log
    {
        public static String username { get; set; }
        public static String pwd { get; set; }
    }
}
