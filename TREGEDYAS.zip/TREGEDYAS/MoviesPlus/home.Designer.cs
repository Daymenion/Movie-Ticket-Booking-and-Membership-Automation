﻿namespace BookMyshow
{
    partial class home
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(home));
            this.homegrpbx = new System.Windows.Forms.GroupBox();
            this.mtitle4 = new System.Windows.Forms.Label();
            this.mtitle3 = new System.Windows.Forms.Label();
            this.mtitle2 = new System.Windows.Forms.Label();
            this.mtitle1 = new System.Windows.Forms.Label();
            this.swallbtn = new System.Windows.Forms.Button();
            this.subpic4 = new System.Windows.Forms.PictureBox();
            this.subpic3 = new System.Windows.Forms.PictureBox();
            this.subpic2 = new System.Windows.Forms.PictureBox();
            this.subpic1 = new System.Windows.Forms.PictureBox();
            this.slidepic3 = new System.Windows.Forms.PictureBox();
            this.slidepic2 = new System.Windows.Forms.PictureBox();
            this.slideshowpic1 = new System.Windows.Forms.PictureBox();
            this.slidepic4 = new System.Windows.Forms.PictureBox();
            this.slidetimer = new System.Windows.Forms.Timer(this.components);
            this.homegrpbx.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.subpic4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.subpic3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.subpic2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.subpic1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.slidepic3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.slidepic2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.slideshowpic1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.slidepic4)).BeginInit();
            this.SuspendLayout();
            // 
            // homegrpbx
            // 
            this.homegrpbx.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.homegrpbx.BackColor = System.Drawing.Color.Transparent;
            this.homegrpbx.Controls.Add(this.mtitle4);
            this.homegrpbx.Controls.Add(this.mtitle3);
            this.homegrpbx.Controls.Add(this.mtitle2);
            this.homegrpbx.Controls.Add(this.mtitle1);
            this.homegrpbx.Controls.Add(this.swallbtn);
            this.homegrpbx.Controls.Add(this.subpic4);
            this.homegrpbx.Controls.Add(this.subpic3);
            this.homegrpbx.Controls.Add(this.subpic2);
            this.homegrpbx.Controls.Add(this.subpic1);
            this.homegrpbx.Controls.Add(this.slidepic3);
            this.homegrpbx.Controls.Add(this.slidepic2);
            this.homegrpbx.Controls.Add(this.slideshowpic1);
            this.homegrpbx.Controls.Add(this.slidepic4);
            this.homegrpbx.Location = new System.Drawing.Point(10, 9);
            this.homegrpbx.Name = "homegrpbx";
            this.homegrpbx.Size = new System.Drawing.Size(734, 545);
            this.homegrpbx.TabIndex = 0;
            this.homegrpbx.TabStop = false;
            this.homegrpbx.Enter += new System.EventHandler(this.groupBox1_Enter);
            // 
            // mtitle4
            // 
            this.mtitle4.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.mtitle4.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.mtitle4.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.mtitle4.Location = new System.Drawing.Point(498, 494);
            this.mtitle4.Name = "mtitle4";
            this.mtitle4.Size = new System.Drawing.Size(142, 14);
            this.mtitle4.TabIndex = 19;
            this.mtitle4.Text = "                                           ";
            // 
            // mtitle3
            // 
            this.mtitle3.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.mtitle3.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.mtitle3.Location = new System.Drawing.Point(341, 494);
            this.mtitle3.Name = "mtitle3";
            this.mtitle3.Size = new System.Drawing.Size(144, 14);
            this.mtitle3.TabIndex = 18;
            this.mtitle3.Text = "                                           ";
            // 
            // mtitle2
            // 
            this.mtitle2.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.mtitle2.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.mtitle2.Location = new System.Drawing.Point(184, 494);
            this.mtitle2.Name = "mtitle2";
            this.mtitle2.Size = new System.Drawing.Size(144, 14);
            this.mtitle2.TabIndex = 17;
            this.mtitle2.Text = "                                           ";
            // 
            // mtitle1
            // 
            this.mtitle1.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.mtitle1.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.mtitle1.Location = new System.Drawing.Point(27, 494);
            this.mtitle1.Name = "mtitle1";
            this.mtitle1.Size = new System.Drawing.Size(144, 14);
            this.mtitle1.TabIndex = 16;
            this.mtitle1.Text = "                                           ";
            // 
            // swallbtn
            // 
            this.swallbtn.BackColor = System.Drawing.Color.Black;
            this.swallbtn.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.swallbtn.Location = new System.Drawing.Point(655, 303);
            this.swallbtn.Name = "swallbtn";
            this.swallbtn.Size = new System.Drawing.Size(47, 177);
            this.swallbtn.TabIndex = 15;
            this.swallbtn.Text = "Show More";
            this.swallbtn.UseVisualStyleBackColor = false;
            this.swallbtn.Click += new System.EventHandler(this.swallbtn_Click);
            // 
            // subpic4
            // 
            this.subpic4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.subpic4.InitialImage = ((System.Drawing.Image)(resources.GetObject("subpic4.InitialImage")));
            this.subpic4.Location = new System.Drawing.Point(501, 303);
            this.subpic4.Name = "subpic4";
            this.subpic4.Size = new System.Drawing.Size(142, 177);
            this.subpic4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.subpic4.TabIndex = 14;
            this.subpic4.TabStop = false;
            this.subpic4.Click += new System.EventHandler(this.subpic4_Click);
            // 
            // subpic3
            // 
            this.subpic3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.subpic3.InitialImage = ((System.Drawing.Image)(resources.GetObject("subpic3.InitialImage")));
            this.subpic3.Location = new System.Drawing.Point(344, 303);
            this.subpic3.Name = "subpic3";
            this.subpic3.Size = new System.Drawing.Size(142, 177);
            this.subpic3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.subpic3.TabIndex = 13;
            this.subpic3.TabStop = false;
            this.subpic3.Click += new System.EventHandler(this.subpic3_Click);
            // 
            // subpic2
            // 
            this.subpic2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.subpic2.InitialImage = ((System.Drawing.Image)(resources.GetObject("subpic2.InitialImage")));
            this.subpic2.Location = new System.Drawing.Point(187, 303);
            this.subpic2.Name = "subpic2";
            this.subpic2.Size = new System.Drawing.Size(142, 177);
            this.subpic2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.subpic2.TabIndex = 12;
            this.subpic2.TabStop = false;
            this.subpic2.Click += new System.EventHandler(this.subpic2_Click);
            // 
            // subpic1
            // 
            this.subpic1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.subpic1.InitialImage = ((System.Drawing.Image)(resources.GetObject("subpic1.InitialImage")));
            this.subpic1.Location = new System.Drawing.Point(30, 303);
            this.subpic1.Name = "subpic1";
            this.subpic1.Size = new System.Drawing.Size(142, 177);
            this.subpic1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.subpic1.TabIndex = 11;
            this.subpic1.TabStop = false;
            this.subpic1.Click += new System.EventHandler(this.subpic1_Click);
            // 
            // slidepic3
            // 
            this.slidepic3.InitialImage = ((System.Drawing.Image)(resources.GetObject("slidepic3.InitialImage")));
            this.slidepic3.Location = new System.Drawing.Point(30, 38);
            this.slidepic3.Name = "slidepic3";
            this.slidepic3.Size = new System.Drawing.Size(674, 238);
            this.slidepic3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.slidepic3.TabIndex = 21;
            this.slidepic3.TabStop = false;
            this.slidepic3.Click += new System.EventHandler(this.slidepic3_Click);
            // 
            // slidepic2
            // 
            this.slidepic2.InitialImage = ((System.Drawing.Image)(resources.GetObject("slidepic2.InitialImage")));
            this.slidepic2.Location = new System.Drawing.Point(30, 38);
            this.slidepic2.Name = "slidepic2";
            this.slidepic2.Size = new System.Drawing.Size(674, 238);
            this.slidepic2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.slidepic2.TabIndex = 20;
            this.slidepic2.TabStop = false;
            this.slidepic2.Click += new System.EventHandler(this.slidepic2_Click);
            // 
            // slideshowpic1
            // 
            this.slideshowpic1.InitialImage = ((System.Drawing.Image)(resources.GetObject("slideshowpic1.InitialImage")));
            this.slideshowpic1.Location = new System.Drawing.Point(30, 38);
            this.slideshowpic1.Name = "slideshowpic1";
            this.slideshowpic1.Size = new System.Drawing.Size(674, 238);
            this.slideshowpic1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.slideshowpic1.TabIndex = 10;
            this.slideshowpic1.TabStop = false;
            this.slideshowpic1.Click += new System.EventHandler(this.slideshowpic1_Click);
            // 
            // slidepic4
            // 
            this.slidepic4.InitialImage = ((System.Drawing.Image)(resources.GetObject("slidepic4.InitialImage")));
            this.slidepic4.Location = new System.Drawing.Point(30, 38);
            this.slidepic4.Name = "slidepic4";
            this.slidepic4.Size = new System.Drawing.Size(674, 238);
            this.slidepic4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.slidepic4.TabIndex = 22;
            this.slidepic4.TabStop = false;
            this.slidepic4.Click += new System.EventHandler(this.slidepic4_Click);
            // 
            // slidetimer
            // 
            this.slidetimer.Tick += new System.EventHandler(this.slidetimer_Tick);
            // 
            // home
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(754, 566);
            this.Controls.Add(this.homegrpbx);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "home";
            this.Text = "home";
            this.Load += new System.EventHandler(this.home_Load);
            this.homegrpbx.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.subpic4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.subpic3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.subpic2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.subpic1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.slidepic3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.slidepic2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.slideshowpic1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.slidepic4)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox homegrpbx;
        private System.Windows.Forms.Label mtitle4;
        private System.Windows.Forms.Label mtitle3;
        private System.Windows.Forms.Label mtitle2;
        private System.Windows.Forms.Label mtitle1;
        private System.Windows.Forms.Button swallbtn;
        private System.Windows.Forms.PictureBox subpic4;
        private System.Windows.Forms.PictureBox subpic3;
        private System.Windows.Forms.PictureBox subpic2;
        private System.Windows.Forms.PictureBox subpic1;
        private System.Windows.Forms.PictureBox slideshowpic1;
        private System.Windows.Forms.Timer slidetimer;
        private System.Windows.Forms.PictureBox slidepic3;
        private System.Windows.Forms.PictureBox slidepic2;
        private System.Windows.Forms.PictureBox slidepic4;
    }
}